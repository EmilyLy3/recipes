from flask import Flask

app = Flask(__name__)
app.secret_key = "Dang I don't think I ever changed this for this project"